import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminmainpage',
  templateUrl: './adminmainpage.component.html',
  styleUrls: ['./adminmainpage.component.css']
})
export class AdminmainpageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  Logout(){
    sessionStorage.clear();
    
  }

}
